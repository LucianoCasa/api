package main

import (
	"log"
	"net"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/lucianocasa/api/internal/api/graphql"
	"github.com/lucianocasa/api/internal/api/grpcapi"
	"github.com/lucianocasa/api/internal/api/rest"
	"github.com/lucianocasa/api/internal/order"
	"google.golang.org/grpc"
)

func main() {
	db, err := order.InitMySQL("user:pass@tcp(db:3306)/ordersdb")
	if err != nil {
		log.Fatalf("DB error: %v", err)
	}
	// defer db.Close()

	repo := order.NewRepository(db)
	service := order.NewService(repo)

	// REST
	go func() {
		router := gin.Default()
		rest.RegisterRoutes(router, service)
		log.Println("REST server at :8080")
		router.Run(":8080")
	}()

	// GraphQL
	http.Handle("/graphql", graphql.NewHandler(service))
	log.Println("GraphQL server at :8081")
	http.ListenAndServe(":8081", nil)

	// gRPC
	log.Println("Starting gRPC server...")
	go func() {
		log.Println("gRPC server at :50051 ini")
		lis, err := net.Listen("tcp", ":50051")
		if err != nil {
			log.Fatalf("Failed to listen: %v", err)
		}
		s := grpc.NewServer()
		grpcapi.Register(s, service)
		log.Println("gRPC server at :50051")
		s.Serve(lis)
	}()
}
