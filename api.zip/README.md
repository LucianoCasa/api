# Desafio: Listagem de Orders REST/gRPC/GraphQL

## Como executar

```bash
docker compose up --build
```

## Endpoints

- REST: http://localhost:8080/order
- gRPC: porta 50051 
- GraphQL: http://localhost:8081/graphql

## Banco de dados

- MySQL 8
- Host interno: `db:3306`
- Usuário: `user`
- Senha: `pass`
- Banco: `ordersdb`

## Testes

Use o arquivo `api.http` para testar criação e listagem via REST.

## Gerar código

```bash
# gRPC
protoc --go_out=. --go-grpc_out=. proto/order.proto

# GraphQL
gqlgen generate